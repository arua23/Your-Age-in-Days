
function calculateDay(){
    var guestName = document.getElementById("exampleUserName");
    //console.log(guestName.value);
    if(guestName.value == ""){
        alert("Please Enter Your Name to proceed");
        resetWebpage();
    } 
    var birthDate = document.getElementById("userBirthdate");
    //console.log(birthDate.value);
    if(birthDate.value == ""){
        alert("Please Enter Your Date of Birth to proceed");
        //resetWebpage();
    }
    var birthDay = new Date(birthDate.value);
    var today = new Date();
    var ageIndays = Math.floor((today.getTime() - birthDay.getTime())/(1000*3600*24));
    //console.log(ageIndays);
    var message1 = document.createElement("h2");
    var h2text = document.createTextNode("Hello " + guestName.value);
    message1.setAttribute("id", "result-header");
    message1.appendChild(h2text);

    var message2 = document.createElement("p");
    var ptxt = document.createTextNode("You are " + ageIndays + " days old");
    message2.setAttribute("id", "result-body");
    message2.appendChild(ptxt);

    document.getElementById("flex-box-result-disp").appendChild(message1);
    document.getElementById("flex-box-result-disp").appendChild(message2);
}

function resetWebpage(){
    location.reload(true);
}